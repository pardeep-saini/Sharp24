-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2021 at 07:33 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db`
--

-- --------------------------------------------------------

--
-- Table structure for table `best_offer`
--

CREATE TABLE `best_offer` (
  `id` int(11) NOT NULL,
  `offerimage` varchar(255) NOT NULL,
  `offername` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `best_offer`
--

INSERT INTO `best_offer` (`id`, `offerimage`, `offername`) VALUES
(9, 'a37bc8bd29112818227930767a8b9cd11601893536279-77bf02.jpg', 'Electrician Best Offer'),
(10, 'ef0e0ed7661f4d0f5d84fe03a7fad1c71603078782132-dfcd55.jpeg', 'Best Offer In Painting'),
(11, '9bec47eede5d504a2f9f4c09093bdf811615874646690-66ab68.jpeg', 'Modular kitchen'),
(12, 'f755528dd05550ea1607d65f170772c0category_165bfd50.jpg', 'Plumber');

-- --------------------------------------------------------

--
-- Table structure for table `bookservice_number`
--

CREATE TABLE `bookservice_number` (
  `id` int(11) NOT NULL,
  `mobile_no` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookservice_number`
--

INSERT INTO `bookservice_number` (`id`, `mobile_no`) VALUES
(14, '6392416645'),
(15, '9838714337'),
(16, '9838714337'),
(17, '9838714337');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(20) NOT NULL,
  `servicename` varchar(500) NOT NULL,
  `cartid` varchar(500) NOT NULL,
  `selecteditem` varchar(500) NOT NULL,
  `price` varchar(500) NOT NULL,
  `userid` varchar(500) NOT NULL,
  `userName` varchar(500) NOT NULL,
  `useremail` varchar(500) NOT NULL,
  `status` varchar(500) NOT NULL,
  `serviceId` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `servicename`, `cartid`, `selecteditem`, `price`, `userid`, `userName`, `useremail`, `status`, `serviceId`) VALUES
(91, 'Electrician', '15', 'Electrician', '200.00', '171', 'hlo', 'hlo@gmail.com', '1', '96'),
(92, 'Electrician', '16', 'testd', '300.00', '171', 'hlo', 'hlo@gmail.com', '1', '96'),
(93, 'Electrician', '17', 'tetd6', '400.00', '171', 'hlo', 'hlo@gmail.com', '1', '96'),
(94, 'Electrician', '15', 'Electrician', '200.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(95, 'Electrician', '16', 'testd', '300.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(96, 'Electrician', '17', 'tetd6', '400.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(97, 'Electrician', '18', 'testd4', '500.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(98, 'Electrician', '19', 'test2', '600.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(99, 'Electrician', '15', 'Electrician', '200.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(100, 'Electrician', '15', 'Electrician', '200.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(101, 'Electrician', '16', 'testd', '300.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(102, 'Electrician', '17', 'tetd6', '400.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(103, 'Electrician', '18', 'testd4', '500.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(104, 'Electrician', '15', 'Electrician', '200.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(105, 'Electrician', '16', 'testd', '300.00', '215', 'vishal Saini', 'vishalsaini8853@gmail.com', '1', '96'),
(106, 'Electrician', '15', 'Electrician', '200.00', '171', 'hlo', 'hlo@gmail.com', '1', '96'),
(107, 'Electrician', '16', 'testd', '300.00', '171', 'hlo', 'hlo@gmail.com', '1', '96'),
(108, 'Electrician', '17', 'tetd6', '400.00', '171', 'hlo', 'hlo@gmail.com', '1', '96');

-- --------------------------------------------------------

--
-- Table structure for table `cart_info`
--

CREATE TABLE `cart_info` (
  `id` int(11) NOT NULL,
  `fullname` varchar(200) NOT NULL,
  `mobileno` int(50) NOT NULL,
  `altmobileno` int(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `adress1` varchar(255) NOT NULL,
  `landmark` varchar(200) NOT NULL,
  `city` varchar(150) NOT NULL,
  `state` varchar(120) NOT NULL,
  `pincode` int(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `servicename` varchar(255) NOT NULL,
  `servicerate` int(200) NOT NULL,
  `total` int(200) NOT NULL,
  `mainId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `vendorName` varchar(220) NOT NULL,
  `vendorId` int(11) NOT NULL,
  `vendorNumber` int(150) NOT NULL,
  `vendorServicename` varchar(200) NOT NULL,
  `vendorcity` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart_info`
--

INSERT INTO `cart_info` (`id`, `fullname`, `mobileno`, `altmobileno`, `email`, `adress1`, `landmark`, `city`, `state`, `pincode`, `date`, `servicename`, `servicerate`, `total`, `mainId`, `userId`, `vendorName`, `vendorId`, `vendorNumber`, `vendorServicename`, `vendorcity`) VALUES
(23, 'jhjhj', 0, 0, 'hj', 'noida', 'kjhj', 'hjh', 'Uttar%20Pradesh', 201206, '2021-06-06 12:11:55', 'Electrician', 0, 0, 96, 171, 'Tested', 19, 2147483647, 'Electrician', 'Noida'),
(24, 'jdhfjsdfjk', 0, 0, 'hj', 'ghaziabad', 'kjhj', 'hjh', 'Uttar%20Pradesh', 201206, '2021-06-06 13:30:48', 'Electrician', 0, 0, 96, 171, 'vendorName', 20, 2147483647, 'Electrician', 'Ghaziabad'),
(25, 'jai%20saini', 2147483647, 0, 'jaisaini6852%40gmail.com', 'noida', 'make%20some', 'ghaziabad', 'Uttar%20Pradesh', 201206, '2021-06-06 15:48:41', 'Electrician', 0, 0, 96, 215, 'Tested', 19, 2147483647, 'Electrician', 'Noida'),
(26, 'DeepakSaini', 2147483647, 0, 'deepaksaini%40gmail.com', 'noida', 'noida', 'noida', 'Uttar%20Pradesh', 201206, '2021-06-06 16:42:13', 'Electrician', 0, 0, 96, 215, 'Tested', 19, 2147483647, 'Electrician', 'Noida'),
(27, 'AnkitSaini', 2147483647, 0, 'ankitsaini%40gmail.com', 'ghaziabad', 'noida', 'noida', 'Uttar%20Pradesh', 201206, '2021-06-06 16:44:11', 'Electrician', 0, 0, 96, 215, 'pradeep', 18, 2147483647, 'Electrician', 'Ghaziabad'),
(28, 'AnkitSaini', 2147483647, 0, 'ankitsaini%40gmail.com', 'Ghaziabad', 'noida', 'noida', 'Uttar%20Pradesh', 201206, '2021-06-06 16:46:56', 'Electrician', 0, 0, 96, 215, 'vendorName', 20, 2147483647, 'Electrician', 'Ghaziabad');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `service` varchar(50) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `datacolect`
--

CREATE TABLE `datacolect` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `title` varchar(500) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(255) NOT NULL,
  `service` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `datacolect`
--

INSERT INTO `datacolect` (`id`, `image`, `content`, `title`, `date`, `status`, `service`) VALUES
(96, '55e825b0430feb2782cac693be046e0felec.png', '', '', '2021-05-22 12:57:15', '', 'Electrician'),
(115, '86f5c168a397bd074694dc08331534cafridge.png', '', '', '2021-05-26 12:04:11', '', 'Home Appliances'),
(116, 'e183d92aab31534e430f46064d8b4301laptop.jpg', '', '', '2021-05-26 12:05:12', '', 'Laptop'),
(118, '1f36856fd00c77e7c1a9dce7ba835351cameras.png', '', '', '2021-05-26 12:08:01', '', 'Security Camera'),
(119, '6c72223251f02f3fcdf962bae05032f3mob.png', '', '', '2021-05-26 12:09:38', '', 'Mobile'),
(120, 'b492dc9096e0d142bcef522cefe24c7dweb.png', '', '', '2021-05-26 12:09:59', '', 'Web Development'),
(121, 'dfe03b9589a85cbe3c9c533e68827d96carp.png', '', '', '2021-05-26 12:10:11', '', 'Carpenter'),
(122, 'ec7dbcbbad2a338796d58356f2a23462paint.png', '', '', '2021-05-26 12:10:37', '', 'Painter'),
(123, '2c519db5082465518973ed7e4f46744fplum.png', '', '', '2021-05-26 12:11:11', '', 'Plumber'),
(124, '1f7741b8d06a87c22691b7507b85e80emodul.jpg', '', '', '2021-05-26 12:11:45', '', 'Modular Kitchen'),
(125, 'c9c687df74df97f23f8217fade2f721fplim.png', '', '', '2021-05-26 12:19:04', '', 'Wellding'),
(126, '035da654a78f6468689b85789cb29c05gate.png', '', '', '2021-05-26 12:21:42', '', 'Glass Work'),
(127, 'cdcf254c6957d0f5b9c34cbcd71450a5homes.jpg', '', '', '2021-05-31 19:09:32', '', 'Home Decoration'),
(134, '16a2fa997afb7c0a9fa0d2416f0b6989mechanic.jpg', '', '', '2021-05-26 17:07:17', '', 'Mechanic'),
(135, 'c532fc8f71a782a1b97309d4b46dd30fpick.jpg', '', '', '2021-05-26 17:11:03', '', 'Junk Pickup'),
(136, '2f81ffcaf9e80872523d24190d2422f8clen.png', '', '', '2021-05-26 17:12:09', '', 'Home Cleaning'),
(137, '5816b06da102e004821486460a501ad0aluminimum.jpg', '', '', '2021-05-26 17:17:41', '', 'Aluminium Furnishing');

-- --------------------------------------------------------

--
-- Table structure for table `datacolectsub`
--

CREATE TABLE `datacolectsub` (
  `id` int(255) NOT NULL,
  `dataColect` varchar(555) NOT NULL,
  `imgIcon` varchar(255) NOT NULL,
  `iconTitle` varchar(288) NOT NULL,
  `serviceImg` varchar(500) NOT NULL,
  `serviceContent` varchar(10000) NOT NULL,
  `serviceTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `datacolectsub`
--

INSERT INTO `datacolectsub` (`id`, `dataColect`, `imgIcon`, `iconTitle`, `serviceImg`, `serviceContent`, `serviceTitle`) VALUES
(1, '96', '55e825b0430feb2782cac693be046e0felec.png', 'Installation', '55e825b0430feb2782cac693be046e0felec.png', 'ServiceContent', 'ServiceTitle'),
(2, '96', '55e825b0430feb2782cac693be046e0felec.png', 'Repairing', '55e825b0430feb2782cac693be046e0felec.png', 'ServiceContent2', 'ServiceTitle2');

-- --------------------------------------------------------

--
-- Table structure for table `datacolect_api`
--

CREATE TABLE `datacolect_api` (
  `id` int(11) NOT NULL,
  `image` int(255) NOT NULL,
  `contents` int(255) NOT NULL,
  `tittle` int(150) NOT NULL,
  `services_name` int(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `our_staff`
--

CREATE TABLE `our_staff` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `designation` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `otp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `our_staff`
--

INSERT INTO `our_staff` (`id`, `name`, `address`, `mobile`, `designation`, `email`, `otp`) VALUES
(1, 'pradeep', 'muradnagar', '7017636563', 'IT Department', 'pradeepsaini6852@gmail.com', '6852');

-- --------------------------------------------------------

--
-- Table structure for table `price_tabe`
--

CREATE TABLE `price_tabe` (
  `id` int(11) NOT NULL,
  `price` varchar(80) NOT NULL,
  `service_name` varchar(120) NOT NULL,
  `dataid` varchar(255) NOT NULL,
  `type` varchar(200) NOT NULL,
  `img` varchar(200) NOT NULL,
  `content` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `price_tabe`
--

INSERT INTO `price_tabe` (`id`, `price`, `service_name`, `dataid`, `type`, `img`, `content`) VALUES
(15, '309.00', 'Ac Switch', '1', 'Installation', 'cdcf254c6957d0f5b9c34cbcd71450a5homes.jpg', 'There’s A Lot Of Flexibility When It Comes To Writing Paragraphs, That’s The Basic Idea, But In Practice There’s More To It. Let’s Look At The Four Main Types Of Paragraphs To Learn How And When To Use Them. But If There’s One Steadfast Rule, It’s This: Paragraphs Should Relate To One Main Topic Or Point. The Paragraph Itself Often Contains Multiple Points Spanning Several Sentences, But They Should All Revolve Around One Core Theme. Just As Sentences Build Upon Each Other To Communicate The Paragraph’s Core Theme, Paragraphs Work Together To Communicate The Core Theme Of The Writing As A Whole. That’s The Basic Idea, But In Practice There’s More To It. Let’s Look At The Four Main Types Of Paragraphs To Learn How And When To Use Them.'),
(16, '499.00', 'Decorative celingin Fan', '1', '', '', ''),
(17, '149.00', 'Simple Fan', '1', '', '', ''),
(18, '89.00', 'Bulb holder', '1', '', '', ''),
(19, '149.00', 'Decorative wall light', '1', '', '', ''),
(20, '600', 'A', '2', 'Repairing', 'cdcf254c6957d0f5b9c34cbcd71450a5homes.jpg', 'There’s A Lot Of Flexibility When It Comes To Writing Paragraphs, That’s The Basic Idea, But In Practice There’s More To It. Let’s Look At The Four Main Types Of Paragraphs To Learn How And When To Use Them. But If There’s One Steadfast Rule, It’s This: Paragraphs Should Relate To One Main Topic Or Point. The Paragraph Itself Often Contains Multiple Points Spanning Several Sentences, But They Should All Revolve Around One Core Theme. Just As Sentences Build Upon Each Other To Communicate The Paragraph’s Core Theme, Paragraphs Work Together To Communicate The Core Theme Of The Writing As A Whole. That’s The Basic Idea, But In Practice There’s More To It. Let’s Look At The Four Main Types Of Paragraphs To Learn How And When To Use Them.'),
(21, '700', 'B', '2', '', '', ''),
(22, '800', 'C', '2', '', '', ''),
(23, '900', 'D', '2', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `review_data`
--

CREATE TABLE `review_data` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `image` varchar(255) NOT NULL,
  `content` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `review_data`
--

INSERT INTO `review_data` (`id`, `name`, `image`, `content`) VALUES
(2, 'Pardeep Saini', 'd62428e94ccf11f2ac7e739ad6c20d20carp.png', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quam neque reiciendis sit. Incidunt tempore vitae aliquam alias voluptatem accusantium magnam eos harum ipsam modi, quisquam illo facilis suscipit maxime obcaecati laboriosam cum blanditiis ducimus ut consectetur id mollitia aperiam rerum.'),
(3, 'Deepak Saini', '38d703be17efebaf69b9e7cf3d286304elec.png', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quam neque reiciendis sit. Incidunt tempore vitae aliquam alias voluptatem accusantium magnam eos harum ipsam modi, quisquam illo facilis suscipit maxime obcaecati laboriosam cum blanditiis ducimus ut consectetur id mollitia aperiam rerum.'),
(4, 'Vishal Saini', 'd7995063ddd94dd951a1e0699fc5d177flag.png', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quam neque reiciendis sit. Incidunt tempore vitae aliquam alias voluptatem accusantium magnam eos harum ipsam modi, quisquam illo facilis suscipit maxime obcaecati laboriosam cum blanditiis ducimus ut consectetur id mollitia aperiam rerum.');

-- --------------------------------------------------------

--
-- Table structure for table `search_engine`
--

CREATE TABLE `search_engine` (
  `id` int(11) NOT NULL,
  `country_name` varchar(150) NOT NULL,
  `country_code` varchar(150) NOT NULL,
  `city` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `servicesimages`
--

CREATE TABLE `servicesimages` (
  `id` int(255) NOT NULL,
  `serviceImage` varchar(150) NOT NULL,
  `priceid` int(255) NOT NULL,
  `type` varchar(200) NOT NULL,
  `content` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `servicesimages`
--

INSERT INTO `servicesimages` (`id`, `serviceImage`, `priceid`, `type`, `content`) VALUES
(1, 'https://servegage.com/storage/602a1dba6d1071613381090-service-image.jpg', 1, 'Installation', 'There’s A Lot Of Flexibility When It Comes To Writing Paragraphs, That’s The Basic Idea, But In Practice There’s More To It. Let’s Look At The Four Main Types Of Paragraphs To Learn How And When To Use Them. But If There’s One Steadfast Rule, It’s This: Paragraphs Should Relate To One Main Topic Or Point. The Paragraph Itself Often Contains Multiple Points Spanning Several Sentences, But They Should All Revolve Around One Core Theme. Just As Sentences Build Upon Each Other To Communicate The Paragraph’s Core Theme, Paragraphs Work Together To Communicate The Core Theme Of The Writing As A Whole. That’s The Basic Idea, But In Practice There’s More To It. Let’s Look At The Four Main Types Of Paragraphs To Learn How And When To Use Them'),
(2, 'https://servegage.com/storage/installation-1-11.jpg', 2, 'Repairing', 'This in new content');

-- --------------------------------------------------------

--
-- Table structure for table `service_provider`
--

CREATE TABLE `service_provider` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `email` varchar(80) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` int(11) NOT NULL,
  `select_profession` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sliderimage`
--

CREATE TABLE `sliderimage` (
  `id` int(11) NOT NULL,
  `slider_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sliderimage`
--

INSERT INTO `sliderimage` (`id`, `slider_image`) VALUES
(2, 'daa4d8ecd9dbdfa3672b7b0f8cffdc52carp.png'),
(3, 'e8a8b3dfb0cb0b3d71c7723be5f946f0carp.png'),
(4, '87619c5f4e7dd257cbfed9a0be3e8caecarp.png'),
(5, '7d6662efe81ed7b22bfa7fcf585d1672carp.png'),
(6, '54d5de8e31de6e98a4c1f52ec2882275carp.png'),
(7, '06efceae42ebbe0530feb5f5f85e4063carp.png'),
(8, 'e0ac67d7720ad12d8b2d0bede31d0ffecarp.png'),
(9, 'c5568d29eb5fada008931266c3ed20facarp.png'),
(10, '68d973ba0c43b35422084d9254e3852bcarp.png'),
(11, 'feda45cd175b66986922e6b56bd633bdcarp.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `mobile_no` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `mobile_no`) VALUES
(171, 'hlo', 'hlo@gmail.com', '6392960483'),
(215, 'vishal Saini', 'vishalsaini8853@gmail.com', '+916392416645');

-- --------------------------------------------------------

--
-- Table structure for table `vendorlist`
--

CREATE TABLE `vendorlist` (
  `id` int(11) NOT NULL,
  `vendor_name` varchar(120) NOT NULL,
  `vendor_number` varchar(120) NOT NULL,
  `vendor_location` varchar(255) NOT NULL,
  `location2` varchar(255) NOT NULL,
  `City` varchar(120) NOT NULL,
  `vendor_servicename` varchar(200) NOT NULL,
  `status` varchar(8) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `email` varchar(200) NOT NULL,
  `password` varchar(120) NOT NULL,
  `state` varchar(100) NOT NULL,
  `pin code` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vendorlist`
--

INSERT INTO `vendorlist` (`id`, `vendor_name`, `vendor_number`, `vendor_location`, `location2`, `City`, `vendor_servicename`, `status`, `date`, `email`, `password`, `state`, `pin code`) VALUES
(18, 'pradeep', '7017636563', 'address1', 'address2', 'Ghaziabad', 'Electrician', 'false', '2021-06-07 19:59:38', 'pradeepsaini6852@gmail.com', 'testedata', 'UP', '201206'),
(19, 'Tested', '9267285192', 'Noida', 'Noida', 'Noida', 'Electrician', 'false', '2021-06-07 19:47:51', 'chetu@gmail.com', 'Chetu', 'UP', '201206'),
(20, 'vendorName', '7017636563', 'Ghaziabad', 'Ghaziabad', 'Ghaziabad', 'Electrician', 'true', '2021-06-06 16:46:56', 'vendor@chetu.com', 'Tested', 'UP', '201206');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `best_offer`
--
ALTER TABLE `best_offer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `bookservice_number`
--
ALTER TABLE `bookservice_number`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart_info`
--
ALTER TABLE `cart_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datacolect`
--
ALTER TABLE `datacolect`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datacolectsub`
--
ALTER TABLE `datacolectsub`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `datacolect_api`
--
ALTER TABLE `datacolect_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `our_staff`
--
ALTER TABLE `our_staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `price_tabe`
--
ALTER TABLE `price_tabe`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dataid` (`dataid`);

--
-- Indexes for table `review_data`
--
ALTER TABLE `review_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `search_engine`
--
ALTER TABLE `search_engine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `servicesimages`
--
ALTER TABLE `servicesimages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_provider`
--
ALTER TABLE `service_provider`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `sliderimage`
--
ALTER TABLE `sliderimage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vendorlist`
--
ALTER TABLE `vendorlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `best_offer`
--
ALTER TABLE `best_offer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `bookservice_number`
--
ALTER TABLE `bookservice_number`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `cart_info`
--
ALTER TABLE `cart_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=169;

--
-- AUTO_INCREMENT for table `datacolect`
--
ALTER TABLE `datacolect`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `datacolectsub`
--
ALTER TABLE `datacolectsub`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `datacolect_api`
--
ALTER TABLE `datacolect_api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `our_staff`
--
ALTER TABLE `our_staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `price_tabe`
--
ALTER TABLE `price_tabe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `review_data`
--
ALTER TABLE `review_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `search_engine`
--
ALTER TABLE `search_engine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `servicesimages`
--
ALTER TABLE `servicesimages`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `service_provider`
--
ALTER TABLE `service_provider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `sliderimage`
--
ALTER TABLE `sliderimage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=258;

--
-- AUTO_INCREMENT for table `vendorlist`
--
ALTER TABLE `vendorlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
