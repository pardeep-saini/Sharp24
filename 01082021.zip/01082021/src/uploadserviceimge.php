<?php
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"db");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add product</title>
  <style>
    
  </style>
</head>
<body>
<div class="grid_10">
  <div class="box round first">
    <h2>Add Service Image And Service Name </h2>
    <div class="block">
      <form name="form1" action="" method="POST" enctype="multipart/form-data">
        <table>
          <tr>
            <td>Service Name</td>
            <td><input type="text" name="pnm"></td>
          </tr>
          
         
          <tr>
            <td>Service image</td>
            <td><input type="file" name="pimage"></td>
          </tr>
         
          <tr>
            <td>Service description</td>
            <td><input type="text" name="pdesc"></td>
          </tr>
          <tr>
            <td>Service title</td>
            <td><input type="text" name="stile"></td>
          </tr>
          <tr>
            <td colspan="2" align="center"><input type="submit" name="submit1" value="upload"></td>
          </tr>
        </table>
      </form>
      <?php

      $v1=rand(1111,9999);
      $v2=rand(1111,9999);
      $v3=$v1.$v2;
      $v3=md5($v3);
              if (isset($_POST["submit1"])) {
                
               $fnm=$_FILES["pimage"]['name'];
               $dst="./upload-image/" .$v3.$fnm;
                $dst1=$v3.$fnm;
               move_uploaded_file($_FILES["pimage"]["tmp_name"], $dst);


                mysqli_query($link,"INSERT INTO `datacolect`(`id`, `image`, `content`,  `service` ,`title`)
                 VALUES ( '','$dst1','$_POST[pdesc]','$_POST[pnm]' ,'$_POST[stile]')");



              }
      ?>
    </div>
  </div>
</div>
</body>
</html>