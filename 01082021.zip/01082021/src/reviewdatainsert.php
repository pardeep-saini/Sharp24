
<?php
include 'config.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add product</title>
  <style>
    
  </style>
</head>
<body>
<div class="grid_10">
  <div class="box round first">
    <h2>Add Product</h2>
    <div class="block">
      <form name="form1" action="" method="POST" enctype="multipart/form-data">
        <table>
          <tr>
            <td>customer name</td>
            <td><input type="text" name="cnm"></td>
          </tr>
          
         
          <tr>
            <td>customer image </td>
            <td><input type="file" name="cimage"></td>
          </tr>
         
          <tr>
            <td>custmer content</td>
            <td><input type="text" name="cdesc"></td>
          </tr>
        
          <tr>
            <td colspan="2" align="center"><input type="submit" name="submit1" value="upload"></td>
          </tr>
        </table>
      </form>
      <?php

      $v1=rand(1111,9999);
      $v2=rand(1111,9999);
      $v3=$v1.$v2;
      $v3=md5($v3);
              if (isset($_POST["submit1"])) {
                
               $fnm=$_FILES["cimage"]['name'];
               $dst="./upload-image/" .$v3.$fnm;
                $dst1=$v3.$fnm;
               move_uploaded_file($_FILES["cimage"]["tmp_name"], $dst);


                mysqli_query($link,"INSERT INTO `review_data`(`id`, `name`, `image`, `content`) VALUES ('','$_POST[cnm]','$dst1','$_POST[cdesc]')");



              }
      ?>
    </div>
  </div>
</div>
</body>
</html>