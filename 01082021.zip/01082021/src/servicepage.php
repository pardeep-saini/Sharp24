
<?php
  session_start();
  require_once("./connection/connection.php");
  // if(!isset($_SESSION["fullName"]) && !isset($_GET['id'])) {
  //   header('Location:'. 'http://localhost:8080/sharpservice24/');
  // } 
  // else if (isset($_GET['id'])){
  //   // session_unset();
  //   header('Location:'. 'http://localhost:8080/sharpservice24//servicepage.php');
  // }

      $id = $_GET['id'];
      $_SESSION["mainId"] = $id;
      
      $query="SELECT dc.imgIcon, dc.iconTitle, 
      dc.serviceImg,dc.serviceContent, 
      dc.serviceTitle,
      dc.id,
      dat.service,
      dat.id mainId
      FROM datacolect dat 
      JOIN datacolectsub dc 
      on dat.id=dc.dataColect 
      where dc.dataColect=$id";      
      $stmtVendor = $db->prepare($query);
      $stmtVendor->execute();
      $users = $stmtVendor->fetchAll();

?>

    <?php
   require_once("header/index.php");
    ?>
    <style>
 
   #servicepage img{
     width:65%;
     border: 2px solid black;
      border-radius: 30px;
      padding: 3%;
       margin-left: 51px;
      
   }
   #servicepage img:hover{
     background-color: skyblue;
   }
   #servicepage h2{
     text-align:center;
     font-size: 20px; 
   }
   .topimage img{
     width:100%;
     height:50vh;
     opacity: 0.5;
     margin-top:-6px;
  background: linear-gradient(to right, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.7));
   }
   .topimage h2{
    position: absolute;
    color:white;
  top: 30%;
  left: 50%;
  transform: translate(-50%, -50%);
   }
  
   }
   .first-txt {
            position: absolute;
            top: 17px;
            left: 50px;
            color:white;
   }
    </style>
   <div class="topimage">
                   <img src="../src/img/ServicesBanner.png">   
                   <h2 style="color: #000080;
    font-weight: bold;
    border-bottom: 4px solid #000080;"><?php if(isset($users[0]['service'])) {
                     echo $users[0]['service'] , " Services";
                   } ?></h2>   
           </div>
           <div class="col-md-4">
           <img src="../src/img/test.png" style=" height:100vh;">
           </div>
   <div class="row" style="padding:7%">
<?php
           foreach($users as $row){
                 ?>
                 
                  <div class="col-md-3 col-sm-3 col-6"  id="servicepage">
                    <a href="detailspge.php?id=<?php echo $row['id'];?>" class="text-decoration-none">
                      <div class="image">
                        <img class="border" src="<?php echo '../src/upload-image/'.$row['imgIcon'];  ?>">
                          <h2 ><?php echo $row['iconTitle']; ?></h2>
                      </div>
                    </a>
                  </div>                           
             <?php
         } 
      ?>
       </div>
<?php include("footer.php") ?>