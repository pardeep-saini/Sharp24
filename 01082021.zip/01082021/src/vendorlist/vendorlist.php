<?php
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"db");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add Vendor List</title>
  <style>
    
  </style>
</head>
<body>
<div class="grid_10">
  <div class="box round first">
    <h2>ADD Vendor List </h2>
    <div class="block">
      <form name="form1" action="" method="POST" enctype="multipart/form-data">
        <table>
          <tr>
            <td>Vendor Name</td>
            <td><input type="text" name="vname"></td>
          </tr>
          
         
          <tr>
            <td>Vendor Number</td>
            <td><input type="Number" name="vnumber"></td>
          </tr>
         
          <tr>
            <td>Vendor Location</td>
            <td><input type="text" name="vlocation"></td>
          </tr>
          <tr>
            <td>State</td>
            <td><input type="text" name="vstate"></td>
          </tr>
          <tr>
            <td>Pin Code</td>
            <td><input type="text" name="vcode"></td>
          </tr>
         
          <tr>
         
            <td>Service Name</td>
    
            <td>
            
            <select  type="text" name="vservice">
  <option value="volvo">Select Service</option>
  <?php
                    $query = "SELECT * FROM datacolect";
                    $results=mysqli_query($link, $query);
                    //loop
                    foreach ($results as $country){
                ?>
                        <option value="<?php echo $country["service"];?>"><?php echo $country["service"];?></option>
                <?php
                    }
                ?>
  
</select>
            </td>  
           
    
    
          </tr>
          
          <tr>
            <td>Status</td>
            <td><input type="text" name="vstatus"></td>
          </tr>
          <tr>
            <td>Vendor Email</td>
            <td><input type="text" name="vemail"></td>
          </tr>
          <tr>
            <td>Password</td>
            <td><input type="password" name="vpass"></td>
          </tr>
          <tr>
            <td colspan="2" align="center"><input type="submit" name="submit1" value="upload"></td>
          </tr>
        </table>
      </form>
      <?php

  
              if (isset($_POST["submit1"])) {
                
             
                mysqli_query($link,"INSERT INTO `vendorlist`(`id`, `vendor_name`, `vendor_number`, `vendor_location`,
                 `vendor_servicename`,
                 `status`, `date`,`email`, `password`,`state`, `pin code`)
                 VALUES ('','$_POST[vname]','$_POST[vnumber]','$_POST[vlocation]','$_POST[vservice]',
                 '$_POST[vstatus]','','$_POST[vemail]','$_POST[vpass]','$_POST[vstate]','$_POST[vcode]')");

        



              }
      ?>
    </div>
  </div>
</div>
</body>
</html>