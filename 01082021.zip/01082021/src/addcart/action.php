
<?php
session_start();
require_once("../connection/connection.php");
if(isset($_POST['pid']) && isset($_POST['serviceName']) && isset($_POST['price']))
{
    $id = $_POST['pid'];
    $serviceName = $_POST['serviceName'];
    $mainId = $_POST['mainId'];
    
    $price = $_POST['price'];
    $userId = $_SESSION["user_id"];
    $userName = $_SESSION["fullName"];
    $serviceMainName = $_SESSION['servicename'];
    $userEmail = $_SESSION["email"];
    $sql = "INSERT INTO cart (cartid, selecteditem, price, userid, userName, useremail, servicename,status, serviceId) VALUES (?,?,?,?,?,?,?,?,?)";
    $stmt= $db->prepare($sql);
    $stmt->execute([$id, $serviceName, $price, $userId, $userName, $userEmail, $serviceMainName,true, $mainId]);
    

}
?>