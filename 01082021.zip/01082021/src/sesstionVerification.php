<?php
session_start();
if(isset($_SESSION["fullName"])) {
   session_destroy();
      header('Location:'. 'http://localhost/sharpservice24/src/');
  } else {
    
  } 
?>