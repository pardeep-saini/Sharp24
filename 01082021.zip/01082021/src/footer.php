<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- building CSS -->
 
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>  
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

   <style>
 
   
.hr-or {
    background-color: #cdcdcd;
    overflow:hidden;
    height: 1px;
    margin-top: 0px !important;
    margin-bottom: 0px !important;
  }
footer.nb-footer {
background: #222;
border-top: 4px solid #b78c33; }
footer.nb-footer .about {
margin: 0 auto;
margin-top: 40px;
max-width: 1170px;
text-align: center; }
footer.nb-footer .about p {
font-size: 15px;
color: white;
margin-top: 30px; }
footer.nb-footer .footer-info-single {
margin-top: 30px; }
footer.nb-footer .footer-info-single .title {
color: #aaa;
text-transform: uppercase;
font-size: 16px;
border-left: 4px solid #b78c33;
padding-left: 5px; }
footer.nb-footer .footer-info-single ul li a {
display: block;
color: #aaa;
padding: 2px 0; }
footer.nb-footer .footer-info-single ul li a:hover {
color: #b78c33; }
footer.nb-footer .footer-info-single p {
font-size: 13px;
line-height: 20px;
color: #aaa; }
footer.nb-footer .copyright {
margin-top: 15px;
background: #111;
padding: 7px 0;
color: #999; }
footer.nb-footer .copyright p {
margin: 0;
padding: 0; }
   </style>
</head>
<body>
    
<footer class="nb-footer">
      <div class="container">
      <div class="row">
      <div class="col-sm-12">
      <div class="about">

      
        </div>
      </div>
      </div>
      <div class="col-md-3 col-sm-6">
      <div class="footer-info-single">
        <h2 class="title">Contact Info</h2>
        <ul class="list-unstyled">
          <li><a href="index.php" title=""><i class="fa fa-angle-double-right"></i>E-mail:<a href = "mailto: Support@sharpservice24.com">Support@sharpservice24.com</a></li>
          <li><a href="index.php" title=""><i class="fa fa-angle-double-right"></i>Phone:<a href="tel:+91 7080021197">+91 7080021197</a> </li>
          <li><a href="index.php" title=""><i class="fa fa-angle-double-right"></i>Adress:Ghaziabad</li>
         
        </ul>
      </div>
      </div>
      
      <div class="col-md-3 col-sm-6">
      <div class="footer-info-single">
        <h2 class="title">Company Links</h2>
        <ul class="list-unstyled">
          <li><a href="index.php" title=""><i class="fa fa-angle-double-right"></i>Home</a></li>
          <li><a href="service.php" title=""><i class="fa fa-angle-double-right"></i>Services</a></li>
          <li><a href="#contact" title=""><i class="fa fa-angle-double-right"></i> Contact Us</a></li>
          <li><a href="" title=""><i class="fa fa-angle-double-right"></i> About Us</a></li>
          <li><a href="#projects" title=""><i class="fa fa-angle-double-right"></i> Our Projects</a></li>
        </ul>
      </div>
      </div>
      
      <div class="col-md-3 col-sm-6">
      <div class="footer-info-single">
        <h2 class="title">Security & Policy</h2>
        <ul class="list-unstyled">
          <li><a href="termandcondition.php" title=""><i class="fa fa-angle-double-right"></i> Terms & Conditions</a></li>
          <li><a href="privacypolicy.php" title=""><i class="fa fa-angle-double-right"></i> Privacy Policy</a></li>
          <li><a href="#" title=""><i class="fa fa-angle-double-right"></i> Reviews</a></li>
        
        </ul>
      </div>
      </div>
      
      <div class="col-md-3 col-sm-6">
      <div class="footer-info-single">
        <h2 class="title">Social Link</h2>
        <ul class="list-unstyled">
          <li><a href="#" title=""><i class="fa fa-angle-double-right"></i>Facebook</a></li>
          <li><a href="#" title=""><i class="fa fa-angle-double-right"></i> Instagram</a></li>
          <li><a href="#" title=""><i class="fa fa-angle-double-right"></i>Linkedin</a></li>
          <li><a href="#" title=""><i class="fa fa-angle-double-right"></i> Twitter</a></li>
         
        </ul>
        
      </div>
      </div>
      </div>
      </div>
    
      
      <section class="copyright">
      <div class="container">
      <div class="row">
      <div class="col-sm-6">
      <p>Copyright © 2021. <a href="https://sharpcarry.com/"> Powerd by Sharpcarry.com.</a></p>
      </div>
      
      </div>
      </section>
      </footer>
      

</body>
</html>