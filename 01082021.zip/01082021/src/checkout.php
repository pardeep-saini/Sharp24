<?php
session_start();
require_once("connection/connection.php");
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"db");
if(isset($_POST['remove'])) {
  $sql ="DELETE FROM cart WHERE userid=".$_SESSION["user_id"];
  $db->exec($sql);
}


/* Get the cart data from cart table */
if(isset($_SESSION["user_id"])) {
  $sql ="SELECT * FROM cart WHERE userid=".$_SESSION["user_id"];
  $userId = $_SESSION["user_id"];
  $sql1 = 'SELECT * FROM `cart` WHERE userid='.$_SESSION["user_id"];
  $st = $db->prepare($sql1);
  $st->execute();
  $totalCount = $st->rowCount();
  $stmt = $db->prepare($sql);
  $stmt->execute();
  $users = $stmt->fetchAll();
  $serviceId = $users[0]['serviceId'];
}
/* End */
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
/* body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
} */



.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

#container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 10px 10px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #04AA6D;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>
</head>
<body>
<?php
require_once("header/index.php");
?>


<div class="container">
  <div class="row">
    <div class="col-sm-4">
    <h4>Cart <span class="price" style="color:black"><i class="fa fa-shopping-cart"></i> <b><?php echo $totalCount ?></b></span></h4>
    <?php 
    $count = 0;
    foreach($users as $user) {
      $count = $count + $user['price'];
     ?>
      <p><a href="#"><?php echo $user['selecteditem']?></a> <span class="price"><?php echo $user['price']?></span></p>
     <?php
    }
    ?>
    <hr>
      <p>Total <span class="price" style="color:black"><b><?php echo $count. ".00"; ?></b></span></p>
    </div>
    <div class="col-sm-4">
    <form  action="" method="POST" enctype="multipart/form-data" id="register-form">
      
      <div class="row">
        <div class="col-50">
          <h3>Billing Address</h3>
        
          <input type="text" id="fname" name="firstname" placeholder="Enter Full Name ">
          
          
          <input type="text" id="mobile" name="mobile" placeholder="Enter Mobile No. ">
     
          <input type="text" id="phone" name="phone" placeholder="Enter Alternate Mobile No. ">
       
          <input type="text" id="email" name="email" placeholder="Enter Email" >
       
          <input type="text" id="adr" name="address" placeholder="address" onchange="mainInfo(this.value)">
        
          <input type="text" id="adr" name="landmark" placeholder="Near Place Name">
        
          <input type="text" id="city"  name="city" placeholder="city">

          <div class="row">
            <div class="col-50">
              <label for="state">State</label>
              <input type="text" id="state" Value="Uttar Pradesh" readonly name="state" placeholder="Uttar Pradesh">
            </div>
            <div class="col-50">
              <label for="zip">Pin Code</label>
              <input type="text" id="zip" name="zip" placeholder="Enter Pin Code">
            </div>
          </div>
        </div>

       
      </div>
      <label>
        <input type="checkbox" checked="checked" name="sameadr"> Shipping address same as billing
      </label>
      <input type="hidden" id="serviceid" value=<?php echo $serviceId; ?> name="serviceid" placeholder="serviceid ">
        
      <div class="row">
      <div class="col-"></div>
      </div>
     
    </form>
    </div>
    <div class="col-sm-4">
      <h3>Vender Details</h3>
      <div id="result"></div>
      <div id="resultCheckout"></div>
    </div>
  </div>
</div>

<div class="modal fade" id="getCodeModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
       <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
       </div>
       <div class="modal-body" id="getCode" style="overflow-x: scroll;">
          <h1 style="padding: 5px; margin-left: 144px;color: green;">The record have been saved ! </h1>
       </div>
    </div>
   </div>
 </div>


<div class="container">

<form action="" method="POST" enctype="multipart/form-data">
<div class="row">
  <div class="col-sm-4">
  <input type="button" value="Continue to checkout" class="btn btn-success m-5" id="addItemChekout">
  </div>
  <div class="col-sm-4">
  <input type="submit" name="remove" id="remove" value="Removed Cart " class="btn">
  </div>
</div>
</form>
</div>



   





<div class="row">
  <div class="col-75">
    <div id="container">
    <!-- <div class="col-sm-4">
<input type="button" id="addItemChekout"  class="btn btn-success m-5"  value="Select" />
  </div> -->

  
  
      <?php

if (isset($_POST["submit2"])) {
  echo  $_POST['firstname'];
  // echo $name = $_POST['firstname'];
  // echo $mobile = $_POST['mobile'];
  // echo $phone = $_POST['phone'];
  // echo $email = $_POST['email'];
  // echo $address = $_POST['address'];
  // echo $landmark = $_POST['landmark'];
  // echo $city = $_POST['city'];
  // echo $state = $_POST['state'];
  // echo $zip = $_POST['zip'];

              
             
// mysqli_query($link,"INSERT INTO `cart_info`(`full_name`, `mobile_no`,
//  `alt_mobile_no`, `email`, `adress_1`, `landmark`, `city`, `state`, `pin_code`)
//   VALUES ($_POST['firstname'],$_POST['mobile'],$_POST['phone'],$_POST['email'],
// $_POST['address']',$_POST['landmark'],
//   $_POST['city'],$_POST['state'],$_POST['zip'])");

}
?>
    </div>
  </div>
 
</div>
<?php
include 'footer.php';
?>

</body>
</html>

<script>
function mainInfo(id) {
  
  $.ajax({
      url:"venderinfo/index.php",
      method: "post",
      data: {pid:id},
      success:function(response) {
        $('#result').html(response);
        // closePupUp();
      }
    })
};



$(document).ready(function(){
  $(document).on("click", "#addItemChekout", function(e){
    e.preventDefault();
  // debugger;
    var data = $("#register-form").serialize();
    var res = data.split("&");
    // var res = resResult.split("=");
   var firstName = res[0].split("=")[1];
   
   var mobile = res[1].split("=")[1];
   var phone = res[2].split("=")[1];
   var email = res[3].split("=")[1];
   var address = res[4].split("=")[1];
   var landmark = res[5].split("=")[1];
   var city = res[6].split("=")[1];
   var state = res[7].split("=")[1];
   var zip = res[8].split("=")[1];
   var sameadr = res[9].split("=")[1];
   var serviceId = res[10].split("=")[1];
  //  var serviceID = serviceId;
    $.ajax({
      url:"cartInfo/index.php",
      method: "post",
      data : {firstName:firstName, mobile:mobile, phone:phone,email:email, address:address, landmark:landmark, city:city, state:state,zip:zip, sameadr:sameadr, serviceId:serviceId},
      success:function(response) {
        $('#resultCheckout').text(response);
        $('#getCodeModal').modal('show');

      }
    })
  })
})
</script>

