<?php
include 'config.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add product</title>
  <style>
    
  </style>
</head>
<body>
<div class="grid_10">
  <div class="box round first">
    <h2>Add Product</h2>
    <div class="block">
      <form name="form1" action="" method="POST" enctype="multipart/form-data">
        <table>
          <tr>
            <td>Service image</td>
            <td><input type="file" name="pimage"></td>
          </tr>
          <tr>
            <td colspan="2" align="center"><input type="submit" name="submit5" value="upload"></td>
          </tr>
        </table>
      </form>
      <?php
      $v1=rand(1111,9999);
      $v2=rand(1111,9999);
      $v3=$v1.$v2;
      $v3=md5($v3);
              if (isset($_POST["submit5"])) {
                
               $fnm=$_FILES["pimage"]['name'];
               $dst="./upload-image/" .$v3.$fnm;
                $dst1=$v3.$fnm;
               move_uploaded_file($_FILES["pimage"]["tmp_name"], $dst);


                mysqli_query($link,"INSERT INTO `sliderimage`(`id`, `slider_image`) VALUES ('','$dst1')");



              }
      ?>
    </div>
  </div>
</div>
</body>
</html>