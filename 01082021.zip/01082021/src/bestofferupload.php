<?php
$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"db");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Add product</title>
  <style>
    
  </style>
</head>
<body>
<div class="grid_10">
  <div class="box round first">
    <h2>Add Product</h2>
    <div class="block">
      <form name="form1" action="" method="POST" enctype="multipart/form-data">
        <table>
         
         
          <tr>
            <td>Service image</td>
            <td><input type="file" name="bimage"></td>
          </tr>
         
          <tr>
            <td>Service title</td>
            <td><input type="text" name="bdesc"></td>
          </tr>
          <tr>
            <td colspan="2" align="center"><input type="submit" name="submit2" value="upload"></td>
          </tr>
        </table>
      </form>
      <?php

      $v1=rand(1111,9999);
      $v2=rand(1111,9999);
      $v3=$v1.$v2;
      $v3=md5($v3);
              if (isset($_POST["submit2"])) {
                
               $fnm=$_FILES["bimage"]['name'];
               $dst="./upload-image/" .$v3.$fnm;
                $dst1=$v3.$fnm;
               move_uploaded_file($_FILES["bimage"]["tmp_name"], $dst);


                mysqli_query($link,"INSERT INTO `best_offer`(`id`, `offerimage`,`offername`) VALUES ('','$dst1','$_POST[bdesc]')");



              }
      ?>
    </div>
  </div>
</div>
</body>
</html>