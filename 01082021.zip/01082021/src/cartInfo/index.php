<?php 
require_once("../connection/connection.php");
require_once("../mainid/index.php");

/** 
 * Get the service id and service name
 */
$serviceId = $_POST['serviceId'];
$address = $_POST['address'];
$getServiceName="SELECT * FROM `cart` WHERE serviceId='$serviceId'";
$stmtSericeInfo = $db->prepare($getServiceName);
$stmtSericeInfo->execute();
$SericeInfo = $stmtSericeInfo->fetchAll();
$servicename = $SericeInfo[0]['servicename'];

 /**End */

$query="SELECT * FROM `vendorlist` WHERE vendor_servicename='$servicename' and status='false' and City LIKE '%$address%'";
echo $query."testedmaikin";


$stmtVendor = $db->prepare($query);
$stmtVendor->execute();
$users = $stmtVendor->fetchAll();


$firstName = $_POST['firstName'];
$mobileNumber = $_POST['mobile'];
$email = $_POST['email'];

$landmark = $_POST['landmark'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip = $_POST['zip'];
$sameadr = $_POST['sameadr'];

$servicName = $servicename;
$mainId = $serviceId;
$userId = $_SESSION["user_id"];
$vendorName = $users[0]['vendor_name'];
$vendorId = $users[0]['id'];
$vendorNumber = $users[0]['vendor_number'];
$vendorServicename = $users[0]['vendor_servicename'];
$vendorcity = $users[0]['City'];
$sql = "INSERT INTO `cart_info`(`fullname`, `mobileno`, `email`, `adress1`, `landmark`, `city`, `state`, `pincode`, `servicename`, `mainId`, `userId`, `vendorName`, `vendorId`, `vendorNumber`, `vendorServicename`, `vendorcity`) 
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
$stmt= $db->prepare($sql);
$stmt->execute([$firstName, $mobileNumber, $email, $address, $landmark, $city, $state, $zip,
 $servicName, $mainId, $userId, $vendorName, $vendorId, $vendorNumber, $vendorServicename, $vendorcity]);
$statuTemp = "true";
$sql1 = "UPDATE vendorlist SET status=? WHERE id=?";
$stmt1= $db->prepare($sql1);
$stmt1->execute([$statuTemp, $vendorId]);
 echo $sql, $users[0]['vendor_number'];
die;

?>