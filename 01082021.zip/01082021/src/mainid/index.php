<?php
session_start();
echo $_SESSION["mainId"];
if(isset($_SESSION["mainId"])) {
try {
    $mainId= $_SESSION["mainId"];
} catch(PDOEXCEPTION $e) {
    $e->getMessage();
}
}
 

?>