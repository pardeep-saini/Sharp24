<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">
<style>
    
    *{
	margin: 0;
	padding: 0;
	font-family: 'poppins',sans-serif;
	box-sizing: border-box;
}
.wrapper{
	width: 100%;
	display: flex;
	justify-content: center;
	flex-wrap: wrap;
	text-align: center;
	margin-top: 3%;	
}
.wrapper .containeringh{
	position: relative;
	width: 350px;
	color: #fff;
	margin: 40px 10px;
	padding: 30px 20px;
	border-radius: 3px;
	transition: 0.3s ease;
	border: 1px solid black;
    border-radius: 29px;
}
.wrapper .containeringh .profile{
	position: absolute;
	left: 50%;
	transform: translateX(-50%);
	top: -10%;
	width: 100%;
	display: block;
}
.wrapper .containeringh .profile .imgBox{
	position: relative;
	height: 100px;
	width: 100px;
	margin: auto;
	border: 1px solid #070c0d;
	border-radius: 50%;
	overflow: hidden;
}
.wrapper .containeringh .profile .imgBox img{
	position: absolute;
	height: 100%;
	width: 100%;
	top: 0;
	left: 0;
	border-radius: 50%;
	object-fit: cover;
	transition: 0.3s ease;
}
.wrapper .containeringh .profile .imgBox:hover img{
	filter: saturate(140%);
	transform: scale(0.95);
}
.wrapper .containeringh h2{
	font-size:15px;
	text-transform: capitalize;
	color: black;
	letter-spacing: 1px;
	text-align: right;
    border-bottom: 3px solid #ea8901;
	margin-left: 59%;
	
}
.wrapper .containeringh p{
	margin-top: 96px;
	text-align:justify;
	color: black;
	padding: 0 8px;
	font-size: 15px;
	opacity: 0.8;
	
}
.wrapper .containeringh .left{
	font-size: 30px;
	display: block;
	text-align: left;
	color: #3b7cf5;	
}
.wrapper .containeringh .right{
	font-size: 30px;
	display: block;
	text-align: right;
	color: #3b7cf5;	
	
}

    </style>
</head>
<body>
	<section>
	<?php
      $conn=mysqli_connect("localhost","root","","db");
      $query="SELECT * FROM review_data";
      $query_run = mysqli_query($conn , $query);
      ?>
	<h3 id="offertag"><span class="headingtop">Customer Review</span></h3>

		<div class="wrapper">
		<?php
          if(mysqli_num_rows($query_run)>0){
           foreach($query_run as $row){
                 ?> 
			<div class="containeringh">
				<div class="profile">
					<div class="imgBox">
						<img src="<?php echo 'upload-image/'.$row['image'];  ?>">
					</div>
				
				</div>
				<p><span class=""></span><?php echo $row['content'];  ?><span class=""></span></p>
				<h2><?php echo $row['name'];  ?></h2>
				
			</div>
		<?php
         }
          }
        else{
        ?>
          echo  "No Record Available";
        <?php
      }
      ?>
	</section>
</body>
</html>