

 <?php
      // session_start();
      require_once("connection/connection.php");
      if (isset($_POST['signin']))  {
      $mobileNUmber = $_POST['mobile'];

      $result = mysqli_query(
        $conn,
       "SELECT * FROM `users` WHERE mobile_no=$mobileNUmber");
        // echo mysqli_num_rows($result);
        if(mysqli_num_rows($result)>0){
        $row = mysqli_fetch_array($result);
        $full_name = $row['full_name'];
        $email = $row['email'];
        $id = $row['id'];
        $_SESSION["fullName"] =$full_name;
        $_SESSION["email"] = $email;
        $_SESSION["user_id"] = $id;
        header('Location:'. 'http://localhost/sharpservice24/src/');
        } 
        
      } else if(isset($_POST['logout'])) {
       
        session_destroy();
        session_destroy();
      }

      /* Get the total count data on the cart table */
      if(isset($_SESSION["user_id"])) {
        $userId = $_SESSION["user_id"];
        $sql = 'SELECT * FROM `cart` WHERE userid='.$userId;
        $st = $db->prepare($sql);
        $st->execute();
        $totalCount = $st->rowCount();
      }
 
   
      /* End */
      ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- font awesome file link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="../css/style.css">
</head>
<style>
</style>
<body>

<header class="header" style="background: #000080;display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    padding: 0rem 2rem;
    height: 10vh;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 100;">
<a href="index.php" id="logo">
<img src="image/logo-icon.png"></a>
<div class="fas fa-bars"></div>
<nav class="navbar">
  <ul>
  <li><a href="#" id="location">
    <i class="fas fa-phone" aria-hidden="true"> </i></a></li>

    <li><a href="#home">home</a></li>
    <li><a href="#bestOffer">services</a></li>
    <li><a href="#faq" id="location">
    <i class="fas fa-map-marker-alt"> </i></a></li>
   

    <?php 
                if(isset($_SESSION["fullName"])) {
                  ?>
<li><a href="sesstionVerification.php" id="logout" name="logout"><i class="fa fa-user" style="font-size:25px; color:white;">
</i></a></li>



<!-- <li><a href="sesstionVerification.php" id="logout" name="logout"><span><h4><?php echo $_SESSION["fullName"]?></h4>  </span>Logout</a></li> -->
                  <?php
                } else {
                  ?>
                  <li><a href="#"  href="#signup" data-toggle="modal" data-target=".log-sign">Login/Signup</a></li>
                  <?php
                }
              ?>
              <?php

              ?>
    <!-- <li><a href="#" id="location"  href="#signup" data-toggle="modal" data-target=".log-sign">Login/Signup</a></li> -->
   <a href="Checkout.php"> <i class="fas fa-shopping-cart"  style="font-size:20px; color:white;" >
   <?php  
    if(isset($_SESSION["fullName"]))  {
      echo $totalCount;
    } else {
      echo 0;
    }
   ?>
   </i></a>
  </ul>
 
</nav>
</header>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
  <!-- <strong>Holy guacamole!</strong> You should check in on some of those fields below. -->
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<div class="modal fade bs-modal-sm log-sign" id="myModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" style="width:49%">
  
    <div class="modal-content">

        <div class="bs-example bs-example-tabs">
       
   
            <ul id="myTab" class="nav nav-tabs">
            <div class="topers">
            <img src="../src/image/logo-icon.png">  
            </div>
            
              <li id="tab1" class=" active tab-style login-shadow "><a href="#signin" data-toggle="tab">Log In</a></li>
              <li id="tab2" class=" tab-style "><a href="#signup" data-toggle="tab">Sign Up</a></li>
              
            </ul>
        </div>
      <div class="modal-body" style="height: 51%;">
        <div id="myTabContent" class="tab-content">
       
        <div class="tab-pane fade active in" id="signin">
            <form class="form-horizontal" style="padding: 5%;">
            <fieldset>
 
               <div class="form-group">
               <input type="text" class="form-control" id="mobile" placeholder="Enter Register Mobile No" name="mobile">
<!-- <input class="input" type="tel" id="loginnum" name="mobile" required placeholder="Enter Register Mobile No."><span class="highlight"></span><span class="bar"></span> -->
    <!-- <label class="labeling" for="date">Enter Register Mobile No.</label></div> -->
            <!-- Button -->
            <div class="control-group">
              <label class="control-label" for="signin"></label>
              <div class="controls">
             
                <button  name="signin"  class="btn btn-primary btn-block" onclick="Loginsuccess()">Log In</button>
                <!-- <button id="login-record" name="signin"  class="btn btn-primary btn-block">Log In</button> -->
                <h4>Already Have Account</h4>
                <h3 id="resultLogin" style="color: green;"></h3>
              </div>
            </div>
            </fieldset>
            </form>
        </div>

        <div class="tab-pane fade" id="signup">
  <form class="form-horizontal" name="user_reg" onsubmit="return validate()" id="submit-info" style="padding: 5%;">
    <div class="form-group">
      <!-- <label for="email">Full Name</label> -->
      <input type="text" class="form-control" id="fname" placeholder="Enter FullName" name="fname">
    
    </div>
    <div class="form-group">
      <input type="email" class="form-control" id="femail" placeholder="Enter email" name="femail">
    </div>
    <div class="form-group">
    <input type="number" class="form-control" id="fmobile" placeholder="Enter mobile" name="fmobile">
      <!-- <input required="" class="input" id="number" name="fmobile" type="number" placeholder="Enter Mobile No"> -->
    </div>
   
    <!-- <button type="submit" class="btn btn-default">Submit</button> -->
    <fieldset>
  <div class="control-group">
    <label class="control-label" for="confirmsignup"></label>
    <div class="controls">
      <input type="button" value="Sign Up" class="btn btn-primary btn-block"  id="signup-record">
      <!-- <button id="confirmsignup" name="confirmsignup" class="btn btn-primary btn-block" id="signup-record">Sign Up</button> -->
      <h4>Does'n Have Account</h4>
      <h3 id="resultCheckout" style="color: green;"></h3>
      <h3 id="resultCheckoutError" style="color: red;"></h3>
     
    </div>
  </div>
  </fieldset>
  </form>
</div>
        
    </div>
      </div>
      <div class="modal-footer">
      <center>
        <button type="button" class="btn btn-default" data-dismiss="modal" onclick="closePupUp()">Close</button>
        </center>
      </div>
    </div>
  </div>
</div>
          </fieldset>
            </form>
          
      </div>
    </div>
    
  </div>
</div>  
<script>
function closePupUp() {
  location.reload();
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="../script/script.js">

</script>

<script>
function validate(){
   var name=documet.user_reg.fullname.value;
   var email=document.user_reg.email.value;
   var phone=document.user_reg.number.value;
     
if (fullname==null || fullname==""){  
  alert("Name can't be blank");  
  return false; 
}
elseif(email==25){
  alert("Email is not Valid");
  return false;
}
elseif(number!==10){
  alert("please enter a valid number");
  return false;
}
else(){
  alert("Successfully Register");
  return true;
}
}
</script>  

<script>
 
 var list1 = [];
        var list2 = [];
        var list3 = [];
        
        var n = 1;
        var x = 0;
    function AddRow(){
              
    list1[x] = document.getElementById("fullname").value;
    list2[x] = document.getElementById("email").value;
    list3[x] = document.getElementById("number").value;
    var myHeaders = new Headers();
    
    myHeaders.append("Content-Type", "application/json");
    
    var raw = JSON.stringify({
        "full_name":list1[x],
       "email":list2[x],
       "mobile_no":list3[x]
      
    });
    
    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw,
      redirect: 'follow'
    };
    
    
    fetch("http://localhost/api/registers.php", requestOptions)
    
      .then(response => response.text())
      
    
    }
    var list1 = []; 
        var n = 1;
        var x = 0;
    function Loginsuccess(){
     
    }


  </script>



</script>

<script>
$(document).ready(function(){
  $(document).on("click", "#signup-record", function(e){
     e.preventDefault();
    var data = $("#submit-info").serialize();

    var res = data.split("&");

   
   let firstName = res[0];
   let email = res[1];
   let mobile = res[2];
   firstName = firstName.split("=")[1];
   email = email.split("=")[1];
   mobile = mobile.split("=")[1];
    $.ajax({
      url:"signup/index.php",
      method: "post",
      data : {firstName:firstName, email:email, mobile:mobile},
      success:function(response) {
        if(response === 'Welcome to our organization and Please login') {
          $('#resultCheckout').text(response);
          $('#resultCheckoutError').text("");
        } else if(response === 'Username already taken') {
          $('#resultCheckoutError').text(response);
          $('#resultCheckout').text("");
        }
      
        // $('#getCodeModal').modal('show');

      }
    })
  })

  $(document).on('click',"#login-record", function(e){
    e.preventDefault();
    var data = $("#login-info").serialize();
    var res = data.split("&");
let mobileNumber = res[0];
mobileNumber = mobileNumber.split("=")[1];
$.ajax({
      url:"loginData/index.php",
      method: "post",
      data : {mobileNumber:mobileNumber},
      success:function(response) {
        // if(response === 'Welcome to our organization and Please login') {
          $('#resultLogin').text(response);
        //   $('#resultCheckoutError').text("");
        // } else if(response === 'Username already taken') {
        //   $('#resultCheckoutError').text(response);
        //   $('#resultCheckout').text("");
        // }
      
        $('#getCodeModal').modal('show');

      }
    })
    debugger;
  })
})
</script>
</body>
</html>

