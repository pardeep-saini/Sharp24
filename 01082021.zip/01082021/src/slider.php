


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
   <style>
   .owl-nav button {
  position: absolute;
  top: 50%;
  background-color: #000;
  color: #fff;
  margin: 0;
  transition: all 0.3s ease-in-out;
}
.owl-nav button.owl-prev {
  left: 0;
}
.owl-nav button.owl-next {
  right: 0;
}

.owl-dots {
  text-align: center;
  padding-top: 15px;
}
.owl-dots button.owl-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  display: inline-block;
  background: #ccc;
  margin: 0 3px;
}
.owl-dots button.owl-dot.active {
  background-color: #000;
}
.owl-dots button.owl-dot:focus {
  outline: none;
}
.owl-nav button {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: rgba(255, 255, 255, 0.38) !important;
}
/* span {
    font-size: 97px;    
    position: relative;
    top: -5px;
} */
.owl-nav button:focus {
    outline: none;
}
.iteming img{
    width:25%;
    height:35vh;
}
@media only screen and (max-width: 700px){
.iteming {
    background: #fff;
    text-align: center;
    padding: 30px 25px;
    -webkit-box-shadow: 0 0px 25px rgb(0 0 0 / 7%);
    box-shadow: 0 0px 25px rgb(0 0 0 / 7%);
    border-radius: 20px;
    border: 5px solid rgba(0, 0, 0, 0.07);
    margin-bottom: 30px;
    -webkit-transition: all .5s ease 0;
    transition: all .5s ease 0;
    transition: all 0.5s ease 0s;
    margin-bottom: 67px;
}

.owl-dots {
  text-align: center;
  margin-top: -23%;
}
}

   </style>
</head>
<body>
<div class="owl-slidering">
<div id="carousel" class="owl-carousel">
	<div class="iteming">
		<img src="img/salon.png" alt="">
	</div>
	<div class="iteming">
		<img src="img/carpe.png" alt="">
	</div>
	<div class="iteming">
		<img src="img/cctv.png" alt="">
	</div>
	<div class="iteming">
		<img src="img/light.png" alt="">
	</div>
  	<div class="iteming">
		<img src="img/plumber.png" alt="">
	</div>
	<div class="iteming">
		<img src="img/web.png" alt="">
	</div>
	<div class="iteming">
		<img src="img/elec.png" alt="">
	</div>
	<div class="iteming">
		<img src="img/clen.png" alt="">
	</div>
  	<div class="iteming">
		<img src="img/carp.png" alt="">
	</div>
	<div class="iteming">
		<img src="img/back.jpg" alt="">
	</div>
</div>
</div>
<script>
jQuery("#carousel").owlCarousel({
  autoplay: true,
  rewind: true, /* use rewind if you don't want loop */
  margin: 20,
   /*
  animateOut: 'fadeOut',
  animateIn: 'fadeIn',
  */
  responsiveClass: true,
  autoHeight: true,
  autoplayTimeout: 7000,
  smartSpeed: 800,
  nav: true,
  responsive: {
    0: {
      items: 1
    },

    600: {
      items: 3
    },

    1024: {
      items: 4
    },

    1366: {
      items: 4
    }
  }
});
</script>
</body>
</html>