<?php 

require_once("../connection/connection.php");

$mobileNumber = $_POST['mobileNumber'];

$getServiceName="SELECT * FROM `users` WHERE mobile_no=$mobileNumber";
$stmtSericeInfo = $db->prepare($getServiceName);
$stmtSericeInfo->execute();
$SericeInfo = $stmtSericeInfo->fetchAll();


?>