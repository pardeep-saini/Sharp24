<?php 
require_once("../connection/connection.php");
    $firstName = $_POST['firstName'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    
    $query="SELECT * FROM `users` WHERE mobile_no='$mobile'";
    $stmtVendor = $db->prepare($query);
    $stmtVendor->execute();
    $users = $stmtVendor->fetchAll();
    if (!empty($users) ) {
        // print_r($users);
        $message='Username already taken';
        echo $message;
        } else {
            $sql = "INSERT INTO `users`(`full_name`, `email`, `mobile_no`) VALUES (?,?,?)";
           $stmt= $db->prepare($sql);
           $stmt->execute([$firstName, $email, $mobile]);
           $message='Welcome to our organization and Please login';
           echo $message;
        }

die;


?>