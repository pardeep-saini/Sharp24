<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
  #privacy{
      margin-top:6%;
      text-align:justify;
      margin-left:5%;
      margin-right:5%;
  }
  @media (max-width:768px){
    #privacy{
      margin-top:20%;
      text-align:justify;
  } 
  #gead {
    margin-top:30%;
  }
}
  #gead h2 {
  background-color: white;
  padding: 3%;
  margin-top:6%;
  text-align: center;
  font-size: 40px;
  color: black; 
   box-shadow: 10px 10px 5px grey;
}

   </style>
</head>
    <?php
   require_once("header/index.php");
    ?>

<div id="gead">
  <h2 >Privacy And Policy
  </h2>
</div>
<p id="privacy">
This Terms of use of agreement was launched dated
........This privacy and policy is effective as per
 launched dated.
Sharpservice24 company respect and values you security
 and privacy.In this privacy policy we discuss or mentioned
  when you are visit on our website www.sharpservice24.com .
   What services are available and use services available on 
   our website . sharpservice24 is committed to maintaining your
    confidence and faith or trust with respect to the personally
     identifiable we collect from you.This privacy policy sets forth
      our practices regarding collection,use and disclosure of information
       collected.
REGISTRATION OF PERSONAL INFORMATION
We may request users or consumers of this site to provide personal 
information.The information collected directly from a user may include 
contact information such as the user's name, e-mail address, and postal
 address. In order to access certain content and to make use of the full 
 functionality of the Site, we ask you to register by completing and submitting 
 a registration form. See our terms of service.
WHAT PERSONAL DATA IS COLLECTED?
We collect the following personal information through different pages on our website: 
(www.sharpservice24.com)
Contact details including first and last name, email address, phone number, and address
Technical support details including which services you are using, how you are using our
 services issues you are facing, questions that you have orders details including which
  services you would like to book, quotation details, and project timeline 
WHEN IS YOUR PERSONAL DATA COLLECTED?
We collect the personal information when:
You register for access to our customer portal
You submit a technical support request with one of our services
You submit a booking request for one of our services
HOW IS EMAIL HANDLED?
We use information you send us by e-mail only for the purpose for which it is 

submitted (e.g., to answer a question, to send information). In addition, if you
 do choose to provide information, it is only used to respond to your request. 

For What Purposes Is Your Personal Data Used?
We collect personal information for the following purposes:
To provide software trials for download to customers and potential customers
To provide technical support to customers and potential customers
To answer services related questions for customers and potential customers
Disclosure of Personal Data to Third Parties
Access to your personal data is restricted to our employees, agents, service representatives,
 and approved third parties that provide commercial services.  We never sell your personal
  data.its completely secure no one see your personal information.  We only distribute your
   information to third parties for the specific purposes listed below or in response to subpoenas,
    court orders, or legal process, or to establish or exercise our rights to defend against legal
     claims, or otherwise required by law in a secure way.

Cookies
We use cookies to help understand how visitors use our website and use this information to
 improve our website services providing.  You can block your browser from using cookies. 
  Here is a link to learn more about cookies.
</p> 



<?php
include 'footer.php';
?>
</html>