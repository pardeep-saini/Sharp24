<?php
session_start(); 
require_once("../connection/connection.php");
if(isset($_POST['pid']) && isset($_SESSION['servicename'])) {
    $address = $_POST['pid'];
    $mainService = $_SESSION['servicename'];
    $conn=mysqli_connect("localhost","root","","db");
    $query="SELECT * FROM `vendorlist` WHERE vendor_servicename='$mainService' and status='false' and City LIKE '%$address%'";

    $st = $db->prepare($query);
  $st->execute();
  $users = $st->fetchAll();
//   $_SESSION['servicename'] = $users[0]['vendor_name'];
    // echo $query;
    // die;
    // $query_run = mysqli_query($conn , $query);
  
} else {
    echo "Vendor details soon...";
}


?>

<?php 

// if(mysqli_num_rows($query_run)>0){
    // foreach($query_run as $row){
        // $_SESSION['vendorName'] = $row['vendor_name'];
        // $_SESSION['vendorId'] = $row['id'];
        // $_SESSION['vendorNumber'] = $row['vendor_number'];
        // $_SESSION['vendorServicename'] = $row['vendor_servicename'];
        // $_SESSION['city'] = $row['City'];
        ?>
        <p>Vendor Name: <?php echo $users[0]['vendor_name']; ?></p>
        <p>Vendor Number: <?php echo $users[0]['vendor_number']; ?></p>
        <p>Specialist: <?php echo $users[0]['vendor_servicename']; ?></p>
        <p>Address: <?php echo $users[0]['City']; ?></p>
        <?php
//     }
// }
?>

