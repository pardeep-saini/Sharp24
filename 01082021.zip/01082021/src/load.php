<?php
      session_start();
        ?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script>
<?php 
// if($_SESSION["status"] = true){
//   return false;
// }
// if(isset($_SESSION["fullName"])) {
//       $_SESSION["status"] = true;
// } else {
 ?>
 
 
 $(window).load(function(){        
   $('#Modal').modal('show');
    }); 
  
    setTimeout(function(){
  $('#Modal').modal('hide')
}, 4000);
 
 <?php
// }



?>
  
</script>
</head>
<body>
<!-- <div id="Modal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <!-- <div class="modal-header">
    <?php 
      if(isset($_SESSION["fullName"])) {
        ?>
         <div class="modal-body">
        <p class="alert alert-success"> Succesfully Login!</p>
      </div>
        <?php
      } else if(!isset($_SESSION["fullName"])) {
        ?>
        
      <div class="modal-body">
        <p class="alert alert-danger"> Login Failed!</p>
      </div>
      <?php
      }
      
      ?>
     
    </div> -->
  </div>
</div>
</body>
</html>