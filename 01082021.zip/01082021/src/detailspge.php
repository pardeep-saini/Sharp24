<?php 

require_once("mainid/index.php");
require_once("connection/connection.php");
if(isset($mainId)) {
 
  $sql1 = 'SELECT * FROM `datacolect` WHERE id='.$mainId;
  $st = $db->prepare($sql1);
  $st->execute();
  $users = $st->fetchAll();
  $_SESSION['servicename'] = $users[0]['service'];
}

?>

<style>
  #colmrate{
    display: flex;
    border: 2px solid #f1f1f1;
    height: 100px;
    width:100%;
    margin-left: 25%;
    margin-bottom: 21px;
    box-sizing: border-box;
    box-shadow: 3px 3px 5px 6px #ccc;
    

  }
  #comimage img{
    width: 125%;
    /* margin-left:-11%; */
  }
  #comimage p{
    font-size:15px;
     text-align:left;
     margin-top:4%;
     list-style: none;
     text-align: justify;
     width: 125%;
 
  }
  #selectbtn{
    margin-left:200%;
    margin-top:20%;
  }
  @media only screen and (max-width: 700px) {
    #comimage img{
 width:100%;
 margin-left:1%;
 margin-top:7%;
  }
  #comimage h3{
    margin-top:30%;
    text-align:center;
  }
  #colmrate{
    display: flex;
    border: 2px solid #f1f1f1;
    height: 100px;
    width:100%;
    margin-left: 0%;
    margin-bottom: 21px;
    box-sizing: border-box;

  }
  #selectbtn{
    margin-left:26%;
    margin-top:25%;
    width:100px;
  }
  }
  .modal-body {
       
       margin:5px;
                padding:2px;
                background-color: white;
                width: 98%;
                height:280px;
                overflow: auto;
                font-size: 20px;
                text-align:justify;
          
    }
    #exampleModalLong{
    }

.product-detail ul{
    margin: 1rem 0;
    font-size: 1.5rem;
        position: relative;

   margin-left: -40px;
  
}
.product-detail ul li{
    margin: 0;
    list-style: none;
    background-size: 18px;
    padding-left: 1.7rem;
    margin: 0.4rem 0;
    font-weight: 600;
    opacity: 0.9;
    padding: 24px;
    margin: 8px 16px 16px;
    border-radius: 4px;
    background-color: #fff;
    box-shadow: 0 6px 20px 0 rgb(0 0 0 / 10%);
  
}
.product-detail ul li span button{
    background-color: green;
    color: white;
    float: right;
}
#pricetab h3{
  /* text-align:center; */
  margin-left: 23%;
    font-size: 156%;

}
#dimage{
  margin-top:7%;
}
#dimage img{
  width:55%;
  margin-left:20%;
  border: 1px solid black;
  border-radius:20px;
}
@media only screen and (max-width: 700px) {
  #dimage{
  margin-top:8%;
  width: 49.99999%;
  float:left;
}
#dimage img{
  width:85%;
  margin-left:auto;
  margin-right:auto;
  border: 1px solid black;
  border-radius:20px;
}
}
.heading{
text-align:center;
}

  </style>
 
<?php
      $conn=mysqli_connect("localhost","root","","db");
      $id = $_GET['id'];
      
      $query="SELECT * 
      FROM datacolectsub ds 
      JOIN price_tabe pt on pt.dataid=ds.id where pt.dataid=$id";
      $getImages = "SELECT * FROM servicesimages WHERE priceid=$id";
      $queryImages = mysqli_query($conn , $getImages);
      if(mysqli_num_rows($queryImages)>0){
        foreach($queryImages as $row){
        }}
      $query_run = mysqli_query($conn , $query);
?>
<?php require_once("header/index.php"); ?>
<div class="heading">
<h2 style="color: #000080;
    font-weight: bold;
    border-bottom: 4px solid #000080;
    width: 19%;
    margin-left: 40%;"><?php if($users[0]['service']) { echo $users[0]['service'];} ?> Service</h2>
</div>

<div class="container" style="padding: 7%;">
  <div class="row">
    <div class="col-sm-6" id="comimage">
      <h3>About The <?php if(isset($row['type'])){echo $row['type'];}?></h3>
      <?php
          if(mysqli_num_rows($queryImages)>0){
           foreach($queryImages as $row){
            
                 ?> 
    <img src=<?php echo $row['serviceImage'] ?> />
  
    <p ><?php if(isset($row['content'])) {echo $row['content'];} ?> </p>
 
<?php
}
    }
    else{
    ?>
    echo  "No Record Available";
    <?php
    }
    ?>
  
        </div>
        
    <div class="col-sm-6" id="pricetab">
      <h3>How can we serve you today?</h3>

      <?php
          if(mysqli_num_rows($query_run)>0){
           foreach($query_run as $row){
                 ?> 
       <form method="post" class="form-submit">          
    <div class="row">
    <div class="sub-service shadow-sm border border-light d-flex" id="colmrate">
    <div class="flex-fill" style="padding: 4%;"><div>
    <input type="hidden" class="pid" value=<?php echo $row['id']; ?> />
    <input type="hidden" class="servicename" value=<?php echo $row['service_name']; ?> />
    <input type="hidden" class="mainid" value=<?php echo $mainId; ?> />
    <p class="name" id="serviceName" name="serviceName" ><?php echo $row['service_name']; ?></p>
    </div>
    <div class="pricing">
    <span class="rupee mr-2 text-muted" style="text-decoration: line-through;">
    <?php echo $row['price']; ?></span>
    <input type="hidden" class="price" value=<?php echo $row['price']; ?> />
    <span class="rupee font-weight-bold"><?php echo $row['price']; ?></span><br>
    <span class="off">(Apx.50% OFF)</span>
    </div>
    </div>
    <div id="result"></div>

    <div class="d-flex align-items-center" style="padding: 27px;
    margin-left: 23%;">
    
    </form>

    <form method="post">
    <?php 
    if(!isset($_SESSION["fullName"])) {
?>
 <input type="button" id="addcart" name="addcart" class="btn btn-success m-5" style="width: 197%;background-color: #000080;"  data-toggle="modal" data-target=".log-sign"  value="Select"></input>
<?php
    } else {
      ?>
       <input type="button" id="addItem" class="btn btn-success m-5"  value="Select"  style="width: 197%;background-color: #000080;" />
      <?php
    }
    
    ?>
       
       

       
    </form>
  
  <div class="modal fade" id="exampleModalLong"
    tabindex="-1" role="dialog"
    aria-labelledby="exampleModalLongTitle"
    aria-hidden="true">
    
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title"
            id="exampleModalLongTitle">
        
          tool collection for creating responsive
          websites and web applications. It is the
          </h5>
          <button type="button" class="close"
            data-dismiss="modal"
            aria-label="Close">

            <span aria-hidden="true" onclick="closePupUp()">
              ×</span>
          </button>
        </div>
        <div class="modal-body">
        
            <div class = "product-detail">
            
              <ul>
                <li>Fiting  Pipe<span><button>ADD</button></span></li>
                <li>Tanki   Fiting<span><button>ADD</button></span></li>
                <li>Repairs Fxing<span><button>ADD</button></span></li>
                <li>Wash Basen<span><button>ADD</button></span></li>
                <li>All Type Plumber Service<span><button>ADD</button></span></li>
              </ul>
            </div>

        </div>

        <div class="modal-footer">
         

          <button type="button"
             class="btn btn-success">
         Checkout-->
          </button>
        </div>
      </div>
    </div>
  </div>
    </div>
    </div>


  </div>
<?php
}
    }
    else{
    ?>
    echo  "No Record Available";
    <?php
    }
    ?>
    </div>
  </div>
</div>

<?php include("footer.php");?>

<script>
$(document).ready(function(){
  $(document).on("click", "#addItem", function(e){
    e.preventDefault();
    var form = $(this).closest(".form-submit");
    var id = form.find(".pid").val();
    var serviceName = form.find(".servicename").val();
    var price = form.find(".price").val();
    var mainId = form.find(".mainId").val();
    
    $.ajax({
      url:"addcart/action.php",
      method: "post",
      data: {pid:id, serviceName:serviceName, price:price,mainId:mainId},
      success:function(response) {
        $('#result').text(response);
        closePupUp();
      }
    })
  })
})

  function closePupUp() {
  location.reload();
}
  </script>