
 <?php
     
     $conn=mysqli_connect("localhost","root","","db");
     $query="SELECT * FROM datacolect";
     $query_run = mysqli_query($conn , $query);
    
     ?>    
<!DOCTYPE html>
<html lang="en">
 
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">

 <!-- font awesome file link  -->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
 <link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <link rel="stylesheet" href="../css/style.css">
 <title>Sharpservice24</title>
 <style>
 </style>
 
</head>
<body>
<?php
include 'load.php';
?>
<?php

require_once("header/index.php");
?>
<div class="row"> 
<div class="col-xs-12">  
<img src="img/Bannerimages.jpg" alt="company logo" style="width: 100%;">

         </div>     
      </div>

<!-- <h1 class="banner">Home Service, On Demand</h1>
<div>
<form class="example" action="/action_page.php">
 <input type="text" placeholder="Search.." name="search">
 
</form>
</div> -->

<!-- <div class="fas fa-cog nut1"></div>
<div class="fas fa-cog nut2"></div> -->
</section>
<!-- home section ends -->
<!-- our service section start -->


<section id="firstsection">  
 
<!-- <div> -->
<h3 id="offertag"><span class="headingtop">Our Services</span></h3>
<!-- </div> -->
<?php
         if(mysqli_num_rows($query_run)>0){
          foreach($query_run as $row){
                ?> 
                 <div class="responsed">
 <div class="offer">


   <a href="servicepage.php?id=<?php echo $row['id'];?>">
   <img src="<?php echo 'upload-image/'.$row['image'];  ?>" width="100px" alt="images">
   </a>
   <div class="desc"><?php echo $row['service'];  ?>  
</div>
 </div>
</div>

                <?php
        }
         }
       else{
       ?>
         echo  "No Record Available";
       <?php
     }
     ?>

<hr>
</section>
<section id="bestOffer">
<?php
     $conn=mysqli_connect("localhost","root","","db");
     $query="SELECT * FROM best_offer";
     $query_run = mysqli_query($conn , $query);
     ?>
<h3 id="offertag"><span class="headingtop">Best Offer</span></h3>
</section>
<?php
         if(mysqli_num_rows($query_run)>0){
          foreach($query_run as $row){
                ?> 
<div class="responseded">
 <div class="offering">
   <a  href="#">
   <img src="<?php echo 'upload-image/'.$row['offerimage'];  ?>" width="100px" alt="images"> 
      </a>
      <div class="desc"> <?php echo $row['offername'];  ?>  </div>

 </div>
</div>
</div>
<?php
        }
         }
       else{
       ?>
         echo  "No Record Available";
       <?php
     }
     ?>


</setion>
<hr>
<section>
<h3 id="offertag"><span class="headingtop">Why Choose Us?</span></h3>
</section>
<div class="choose">
 <div class="chooseimg">
   <img src="img/instant.jpg">
   <h3 id="offertag"><span class="headingtop">Instant Service</span></h3>
   <p class="choosep">If you have any kind of problem we will solve it only in a short time . that too very reasonable price.
   that too very reasonable price. that too very reasonable price.
   </p>
</div>
</div>
<div class="choose">
 <div class="chooseimg">
   <img src="img/instant.jpg">
   
   <h3 id="offertag"><span class="headingtop">Professional Verified</span></h3>
   <p class="choosep" >Whatever your work will be done by the most perfect and honest serviceman.
                       We will try to our best to not give you any chance to complain.
                       </p>
</div>
</div>
<div class="choose">
 <div class="chooseimg">
   <img src="img/instant.jpg">
  
   <h3 id="offertag"><span class="headingtop">Warranty</span></h3>

   <p class="choosep">Whatever work you do by us, the company 
     will provide warrenty facilities for some time according to your work, so that you do not get any chance to complain.</p>
</div>
</div>
<hr>
<?php
include 'slider.php';
?>
<hr>
<section>
<?php
include 'review.php';
?>
</section>
   <hr>
  

   <?php
   include 'footer.php';
   ?>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<script src="script/script.js">
</script> 
<script>
 
// $(window, document, undefined).ready(function() {

// $('.input').blur(function() {
//   var $this = $(this);
//   if ($this.val())
//     $this.addClass('used');
//   else
//     $this.removeClass('used');
// });

// });


// $('#tab1').on('click' , function(){
//   $('#tab1').addClass('login-shadow');
//  $('#tab2').removeClass('signup-shadow');
// });

// $('#tab2').on('click' , function(){
//   $('#tab2').addClass('signup-shadow');
//  $('#tab1').removeClass('login-shadow');


// });
      </script>

</body>
</html>