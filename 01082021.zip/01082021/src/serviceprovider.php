


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0-10/css/all.min.css">
      <!-- font awesome file link  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<style>

@import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,500;1,100;1,200;1,300;1,400;1,500&display=swap');
*{
    margin:0;
    padding:0;
   box-sizing:border-box;
   
}
:root{
    --myfont : 'mulish' sans-serif;
    --my-btn-font:'Poppins' sans-serif;
    --lg-lightcolor: linear-gradient(to left,rgba(116,235,213,0.6) ,rgba(159,172,230,0));
    --lg-color: linear-gradient(to left,#74ebd5 ,#9face6);
}

        .formerror {
            color: red;
        }

        .but {
         
            width: 100px;
            height: 50px;
            font-size: 25px;
            margin: 22px 20px;
        }
        .form-controling{
    margin-bottom:50px;
    position:relative;
}
.form-controling input{
    width:100%;
    padding:8px;
    
}

        .containering{
    background-color:#fff;
  
    --webkit-border-radius:10px;
    box-shadow: 0 2.8px 2.2px rgba(0,0,0,0.34),0 6.7px 5.3px rgba(0,0,0,0.483),0 12;
    overflow:hidden;
    width:calc(100vw-65vw);
    max-width:100%;
}
.headering{
    background:var(--lg-color);
    padding:30px 0;
    margin-top:7%;
}
.headering h2{
    color:#222;
    font-family:  var(--my-btn-font);
    font-size:24px;
    text-transform:uppercase;
    text-align:center;
}
.form{
    padding:40px;
    border:2px solid #f0f0f0;
    display:block;
    border-radius:5px;
    font-family:var(--my-font);
    font-size:15px;
    padding:30px;
    background-image: url("img/siple.jpg");
    
}
.form-controling input:focus{
outline:0;
border-color:#777;
}

.form .btn{
    background:var(--lg-color);
    border-radius:6px;
    border:none;
    outline:none;
    color:#fff;
    display:block;
    font-family:var(--my-btn-font);
    font-size:16px;
  
    margin-top:20px;
    width:100%;
    font-weight:bold;
    text-transform:uppercase;
    transition:all in ease;
}
.form .btn:hover{
    background:linear-gradient(to right,#74ebd5,#9face6);

}
@media(max-width:998px){
    .conatinering{
        width:calc(100vw - 35vw);
        max-width:100%;
    }

}

body{
  overflow-x: hidden;
 
}

.heading{
  margin:2rem;
  padding-top: 6rem;
  display: inline-block;
  font-size: 3.5rem;
  color:var(--color);
  position: relative;
  letter-spacing: .2rem;
}



.btn{
  outline: none;
  border: none;
  border-radius: 5rem;
  background: var(--color);
  color:#fff;
  cursor: pointer;
  height:3.5rem;
  width: 15rem;
  font-size: 1.7rem;
  box-shadow: 0 .2rem .5rem rgba(0,0,0,.3);
}



.header{
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  padding:1rem 2rem;
  position: fixed;
  top:0; left: 0;
  z-index: 100;
  background-color:black;
  text-decoration:none;
}
form.example input[type=text] {
  padding: 8px;
  font-size: 17px;
  border: 1px solid grey;
  margin-left:-55%;
  width: 150%;
  background: white;
  
}
@media (max-width:768px){
  form.example input[type=text] {
  padding: 8px;
  font-size: 17px;
  border: 1px solid grey;
  margin-left:-13%;
  width: 120%;
  background: white;
  
}
}
</style>
</head>

<body>
<?php
require_once("header/index.php");
?>
<div class="containering">
    <div class="headering">
    <h2>Registration Form</h2>
    </div>
    <form aciton ="#" name="myForm" class="form" onsubmit="return validateForm()" method="post">
        <div class="form-controling" id="name" >
           Full Name <input type="text" id="names" name="fname" required  placeholder="Enter Your Full Name"><b><span class="formerror"> </span></b>
        </div>

        <div class="form-controling" id="email">
            Email <input type="email" id="emaile" name="femail" required  placeholder="Enter  Your Email Id"><b><span class="formerror"> </span></b>
        </div>

        <div class="form-controling" id="phone">
           Mobile No.<input type="phone"  id="mobile" name="fphone" required  placeholder="Enter Your Mobile No."><b><span class="formerror"></span></b>
        </div>
        
        <div class="form-controling" id="pass" >
        Select Service <input type="text" id="profession" name="Serviecs" required  placeholder="Select Profession" >
        
        <b><span class="formerror"></span></b>
   
        </div>
        

        <input class="btn" type="submit" value="Submit" onclick="Submited()">

    </form>

<?php
include 'footer.php';
?>

<script>
function clearErrors(){

errors = document.getElementsByClassName('formerror');
for(let item of errors)
{
    item.innerHTML = "";
}


}
function seterror(id, error){
//sets error inside tag of id 
element = document.getElementById(id);
element.getElementsByClassName('formerror')[0].innerHTML = error;

}

function validateForm(){
var returnval = true;
clearErrors();

//perform validation and if validation fails, set the value of returnval to false
var name = document.forms['myForm']["fname"].value;
if (name.length<5){
    seterror("name", "*Length of name is too short");
    returnval = false;
}

if (name.length == 0){
    seterror("name", "*Length of name cannot be zero!");
    returnval = false;
}

var email = document.forms['myForm']["femail"].value;
if (email.length>25){
    seterror("email", "*Email length is too long");
    returnval = false;
}

var phone = document.forms['myForm']["fphone"].value;
if (phone.length != 10){
    seterror("phone", "*Phone number should be of 10 digits!");
    returnval = false;
}


return returnval;
}

</script>

<script>
$(document).ready(function(){


$('.fa-bars').click(function(){
  $(this).toggleClass('fa-times');
  $('.navbar').toggleClass('nav-toggle');
});



$('.accordion-header').click(function(){
  $('.accordion .accordion-body').slideUp();
  $(this).next('.accordion-body').slideDown();
  $('.accordion .accordion-header span').text('+');
  $(this).children('span').text('-');
});



});
</script>
  <script>
       
		var list1 = [];
		var list2 = [];
		var list3 = [];
        var list4 = [];
		var n = 1;
		var x = 0;
function Submited(){
          
list1[x] = document.getElementById("names").value;
list2[x] = document.getElementById("emaile").value;
list3[x] = document.getElementById("mobile").value;
list4[x] = document.getElementById("profession").value;

var myHeaders = new Headers();

myHeaders.append("Content-Type", "application/json");

var raw = JSON.stringify({
    "name":list1[x],
   "email":list2[x],
   "phone":list3[x],  
   "select_profession":list4[x]
  
});

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: raw,
  redirect: 'follow'
};

fetch("http://localhost/api/provider.php", requestOptions)
  .then(response => response.text())
  .then(result => {
    if(result) {
        alert(result);
    }
   
  })
 
  .catch(error => console.log('error', error));


console.log("List>>>", data)

}
</script>

</body>
</html>