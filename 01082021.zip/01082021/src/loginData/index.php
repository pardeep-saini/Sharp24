<?php 
require_once("../connection/connection.php");
    $mobileNumber = $_POST['mobileNumber'];

    
   
    $query="SELECT * FROM `users` WHERE mobile_no='$mobileNumber'";
    $stmtVendor = $db->prepare($query);
    $stmtVendor->execute();
    $users = $stmtVendor->fetchAll();
    count($users);
    if(count($users)>0) {
        echo "Login Success";
        // header('Location:'. 'http://localhost/sharpservice24/src/');
        header("refresh: 3; url = http://localhost/sharpservice24/src");
    } else if(count($users)===0) {
        echo "wrong credentials";
    }
    die;
    // foreach($users as $user) {
    //     // print_r($user['full_name']);
    //     $full_name = $user['full_name'];
    //      $email = $user['email'];
    //      $id = $user['id'];
    //      $_SESSION["fullName"] =$full_name;
    //      $_SESSION["email"] = $email;
    //      $_SESSION["user_id"] = $id;
    //     //  header('Location:'. 'http://localhost/sharpservice24/src/');
    //     echo  $full_name, $email, $id;
       
    //     // $id = $user['id'];
    //     // $_SESSION["fullName"] =$full_name;
    //     // $_SESSION["email"] = $email;
    //     // $_SESSION["user_id"] = $id;
    //     // $message='UserLogin';
    //     // header('Location:'. 'http://localhost/sharpservice24/src/');
    // }
    
    // $full_name = $users['full_name'];
    // if (!empty($users) ) {
    //     // print_r($users);
    //     $message='UserLogin';
        // echo $full_name;
    // }



    // $result = mysqli_query(
    //     $conn,
    //    "SELECT * FROM `users` WHERE mobile_no=$mobileNUmber");
    //     // echo mysqli_num_rows($result);
    //     if(mysqli_num_rows($result)>0){
    //     $row = mysqli_fetch_array($result);
    //     $full_name = $row['full_name'];
    //     $email = $row['email'];
    //     $id = $row['id'];
    //     $_SESSION["fullName"] =$full_name;
    //     $_SESSION["email"] = $email;
    //     $_SESSION["user_id"] = $id;
    //     header('Location:'. 'http://localhost/sharpservice24/src/');

die;


?>